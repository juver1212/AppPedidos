package com.jahesa.apppedidos;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Camera;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.StrictMode;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;


public class Guia_detalle extends AppCompatActivity{

    private final int REQUEST_CODE_ASK_PERMISSIONS = 123;
    private final String ruta_fotos = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/Transporte/";
    private File file = new File(ruta_fotos);
    Uri uri;
    ImageView cuadro;
    TextView texto;
    Button boton, boton2, boton_despacho;
    CheckBox check,check_atendido;
    ListView lv1;
    EditText edit1, edit2;
    Spinner spi;
    ArrayAdapter<String> adapter;
    ArrayList<String> datos;
    private ProgressDialog pDialog;
    String  status="",myBase64Image="",num_guia = "", imei = "", url = "http://www.jahesa.com/transporte/index.php/",transportista = "", hora = "", lat_extraida = "", lon_extraida = "",hora_atencion="", lat_ext_aten = "",lon_ext_aten="" ;
    int cantidad_fotos = 0;
    Context c;
    JSONArray json;
    String guias[];
    double latitude=0;
    double longitud=0;
    Bitmap bitmap;
    LocationManager locationManager;
    MyLocationListener mlocListener;

    protected void onPause(){
        super.onPause();
        try {
            locationManager.removeUpdates(mlocListener);
        } catch (SecurityException e) {
            Log.e("PERMISSION_EXCEPTION","PERMISSION_NOT_GRANTED");
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guia_detalle);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mlocListener = new MyLocationListener();
        mlocListener.setMainActivity(this);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,(LocationListener) mlocListener);
        /*Location location = locationManager.getLastKnownLocation(locationManager.getBestProvider(criteria, false));*/

        boton_despacho = (Button) findViewById(R.id.button);
        boton = (Button) findViewById(R.id.boton);
        //boton2 = (Button) findViewById(R.id.button2);
        texto = (TextView) findViewById(R.id.txtHeader);
        check = (CheckBox) findViewById(R.id.chk1);
        check_atendido = (CheckBox) findViewById(R.id.chk2);
        edit1 = (EditText) findViewById(R.id.campo_mensaje);
        edit2 = (EditText) findViewById(R.id.editText);
        spi = (Spinner) findViewById(R.id.spinner);


        //LLENADO DE SPINNER OBSERVACION
        Spinner spinner_animales = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter spinner_adapter = ArrayAdapter.createFromResource(this, R.array.Observacion, android.R.layout.select_dialog_singlechoice);
        spinner_adapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        spinner_animales.setAdapter(spinner_adapter);

        Bundle bundle = getIntent().getExtras();
        num_guia = bundle.getString("documento");
        texto.setText("Guia N° " + num_guia);
        new Validar_Checkbox().execute(num_guia);
        new Validar_Foto().execute(num_guia);

        Button button= (Button) findViewById(R.id.boton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.setVmPolicy(builder.build());

                //Si no existe crea la carpeta donde se guardaran las fotos
                file.mkdirs();
                String file = ruta_fotos + getCode() + ".jpg";
                File mi_foto = new File(file);
                try {
                    mi_foto.createNewFile();
                } catch (IOException ex) {
                    Log.e("ERROR ", "Error:" + ex);
                }
                //
                uri = Uri.fromFile(mi_foto);
                //Abre la camara para tomar la foto
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //Guarda imagen
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                //Retorna a la actividad
                startActivityForResult(cameraIntent, 0);
            }
        });

    }

    public void MarcarCheckbox(View v) {
        check.setChecked(true);
        new MarcadoCheck().execute(num_guia, String.valueOf(latitude),String.valueOf(longitud));
    }

    public void MarcarCheckbox_atencion(View v) {
        check_atendido.setChecked(true);
        new MarcadoCheck_Atencion_Cliente().execute(num_guia, String.valueOf(latitude),String.valueOf(longitud));
    }

    public void Despachado(View v) {

        String det_obs = edit1.getText().toString();
        String obs = spi.getSelectedItem().toString();
        String km = edit2.getText().toString();
        String lat = String.valueOf(latitude);
        String lon = String.valueOf(longitud);

        //SI ES DESPACHADO --------------------------

        if(obs.equals("Despacho normal") || obs.equals("Otros despachos") ) {

            if (!det_obs.equals("") && !km.equals("") && check.isChecked() == true) {
                    if (!transportista.equals("")) {
                        if (cantidad_fotos != 0) {
                            new Despachar_Guia().execute(num_guia, det_obs, obs, km, lat, lon);
                        } else {
                            Toast.makeText(getApplicationContext(), "No se ha realizado ninguna foto", Toast.LENGTH_LONG).show();
                            Vibrator d = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                            d.vibrate(600);
                        }
                    } else {
                        new Despachar_Guia().execute(num_guia, det_obs, obs, km, lat, lon);
                    }
                }

                else {
                Toast.makeText(getApplicationContext(), "Campos incorrectos", Toast.LENGTH_LONG).show();
                Vibrator d = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                d.vibrate(600);
            }
        }

        //SI NO ES DESPACHADO --------------------------

        else if (!obs.equals("Despacho normal") && !obs.equals("Otros despachos") && !obs.equals("")){

            if (!det_obs.equals("") && !km.equals("") && check.isChecked() == true ) {
                    new Despachar_Guia().execute(num_guia, det_obs, obs, km, lat, lon);
                }
            else {
                Toast.makeText(getApplicationContext(), "No se ha realizado ninguna foto", Toast.LENGTH_LONG).show();
                Vibrator d = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                d.vibrate(600);
            }
        }

        //SI NO SE SELECCIONA NADA  --------------------------

        else  {
            Toast.makeText(getApplicationContext(), "Seleccione Observacion ", Toast.LENGTH_LONG).show();
            Vibrator d = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            d.vibrate(600);
        }
    }

    public void setLocation(Location loc) {
        //Obtener la direcci—n de la calle a partir de la latitud y la longitud
        if (loc.getLatitude() != 0.0 && loc.getLongitude() != 0.0) {
            try {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> list = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
                if (!list.isEmpty()) {
                    Address address = list.get(0);
                    //edit1.setText("Mi direcci—n es: \n" + address.getAddressLine(0));
                    latitude = loc.getLatitude();
                    longitud = loc.getLongitude();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public class MyLocationListener implements LocationListener {
        Guia_detalle mainActivity;

        public Guia_detalle getMainActivity() {
            return mainActivity;
        }

        public void setMainActivity(Guia_detalle mainActivity) {
            this.mainActivity = mainActivity;
        }

        @Override
        public void onLocationChanged(Location loc) {
            loc.getLatitude();
            loc.getLongitude();
            String Text = "Mi ubicaci—n actual es: " + "\n Lat = "
                    + loc.getLatitude() + "\n Long = " + loc.getLongitude();
            this.mainActivity.setLocation(loc);
        }

        @Override
        public void onProviderDisabled(String provider) {
            edit1.setText("GPS Desactivado");
        }

        @Override
        public void onProviderEnabled(String provider) {
            edit1.setText("GPS Activado");
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }
    }



    private class MarcadoCheck_Atencion_Cliente extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        URL url_new = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        @Override
        protected String doInBackground(String... params) {

            datos = new ArrayList<String>();

            try {

                // Enter URL address where your php file resides
                url_new = new URL(url+ "hojaruta/Grabar_Hora_Atencion");

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "exception";
            }
            try {
                //Setup HttpURLConnection class to send and receive data from php and mysql
                conn = (HttpURLConnection)url_new.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(10000);
                conn.setRequestMethod("POST");

                // setDoInput and setDoOutput method depict handling of both send and receive
                conn.setDoInput(true);
                conn.setDoOutput(true);

                // Append parameters to URL
                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("vp_guia", params[0])
                        .appendQueryParameter("vp_latitud", params[1])
                        .appendQueryParameter("vp_longitud", params[2]);
                String query = builder.build().getEncodedQuery();

                // Open connection for sending data
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                conn.connect();

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return "exception";
            }

            try {

                int response_code = conn.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder result = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return(result.toString());

                }else{

                    return("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "exception";
            } finally {
                conn.disconnect();
            }


        }

        @Override
        protected void onPostExecute(String result) {

            try {
                json = new JSONArray(result);
                String s = "";
                if (json.length() != 0) {
                    for (int i = 0; i < json.length(); i++) {
                        s = json.get(i).toString();
                        JSONObject last = new JSONObject(s);
                        last = json.getJSONObject(i);
                        String documento = last.getString("status");
                        datos.add(documento);
                    }

                }

                if (datos.size() > 0) {
                    Toast.makeText(getApplicationContext(), "Preparando despacho", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error de llegada", Toast.LENGTH_LONG).show();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(600);
                }

            }  catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class MarcadoCheck extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        URL url_new = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        @Override
        protected String doInBackground(String... params) {
            datos = new ArrayList<String>();
            try {

                // Enter URL address where your php file resides
                url_new = new URL(url+ "hojaruta/Grabar_Hora_Llegada");

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "exception";
            }
            try {
                //Setup HttpURLConnection class to send and receive data from php and mysql
                conn = (HttpURLConnection)url_new.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(10000);
                conn.setRequestMethod("POST");

                // setDoInput and setDoOutput method depict handling of both send and receive
                conn.setDoInput(true);
                conn.setDoOutput(true);

                // Append parameters to URL
                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("vp_guia", params[0])
                        .appendQueryParameter("vp_latitud", params[1])
                        .appendQueryParameter("vp_longitud", params[2]);
                String query = builder.build().getEncodedQuery();

                // Open connection for sending data
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                conn.connect();

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return "exception";
            }

            try {

                int response_code = conn.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder result = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return(result.toString());

                }else{

                    return("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "exception";
            } finally {
                conn.disconnect();
            }


        }

        @Override
        protected void onPostExecute(String result) {

            try {
                json = new JSONArray(result);
                String s = "";
                if (json.length() != 0) {
                    for (int i = 0; i < json.length(); i++) {
                        s = json.get(i).toString();
                        JSONObject last = new JSONObject(s);
                        last = json.getJSONObject(i);
                        String documento = last.getString("status");
                        datos.add(documento);
                    }

                }

                if (datos.size() > 0) {
                    Toast.makeText(getApplicationContext(), "Preparando despacho", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error de llegada", Toast.LENGTH_LONG).show();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(600);
                }

            }  catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class Validar_Checkbox extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        URL url_new = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(Guia_detalle.this);
            pDialog.setMessage("Cargando....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... params) {
            datos = new ArrayList<String>();
            try {

                // Enter URL address where your php file resides
                url_new = new URL(url+ "hojaruta/Validar_Checkbox");

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "exception";
            }
            try {
                //Setup HttpURLConnection class to send and receive data from php and mysql
                conn = (HttpURLConnection)url_new.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(10000);
                conn.setRequestMethod("POST");

                // setDoInput and setDoOutput method depict handling of both send and receive
                conn.setDoInput(true);
                conn.setDoOutput(true);

                // Append parameters to URL
                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("vp_guia", params[0]);
                String query = builder.build().getEncodedQuery();

                // Open connection for sending data
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                conn.connect();

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return "exception";
            }

            try {

                int response_code = conn.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder result = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return(result.toString());

                }else{

                    return("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "exception";
            } finally {
                conn.disconnect();
            }


        }

        @Override
        protected void onPostExecute(String result) {

            try {
                json = new JSONArray(result);
                String s = "";
                if (json.length() != 0) {
                    for (int i = 0; i < json.length(); i++) {
                        s = json.get(i).toString();
                        JSONObject last = new JSONObject(s);
                        last = json.getJSONObject(i);
                        hora = last.getString("Hor_LLeg");
                        lat_extraida = last.getString("latitud");
                        lon_extraida = last.getString("longitud");
                        //CHECKBOX DE ATENCION ----------------
                        hora_atencion = last.getString("cliente_atencion");
                        lat_ext_aten = last.getString("latitud_atencion");
                        lon_ext_aten = last.getString("longitud_atencion");
                        transportista = last.getString("serie_guia_trasporte");
                        datos.add(hora);
                    }

                }

                pDialog.dismiss();
                if (!hora.equals("")) {
                    check.setChecked(true);
                    check.setEnabled(false);
                }

                if(!hora_atencion.equals("")){
                    check_atendido.setChecked(true);
                    check_atendido.setEnabled(false);
                }

            }  catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class Despachar_Guia extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        URL url_new = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(Guia_detalle.this);
            pDialog.setMessage("Un momento por favor....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... params) {
            datos = new ArrayList<String>();
            try {

                // Enter URL address where your php file resides
                url_new = new URL(url+ "hojaruta/Actualizar_Guia");

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "exception";
            }
            try {
                //Setup HttpURLConnection class to send and receive data from php and mysql
                conn = (HttpURLConnection)url_new.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(10000);
                conn.setRequestMethod("POST");

                // setDoInput and setDoOutput method depict handling of both send and receive
                conn.setDoInput(true);
                conn.setDoOutput(true);

                // Append parameters to URL
                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("vp_guia", params[0])
                        .appendQueryParameter("vp_det_obs", params[1])
                        .appendQueryParameter("vp_obs", params[2])
                        .appendQueryParameter("vp_km", params[3])
                        .appendQueryParameter("vp_lat", params[4])
                        .appendQueryParameter("vp_lon", params[5]);
                String query = builder.build().getEncodedQuery();

                // Open connection for sending data
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                conn.connect();

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return "exception";
            }

            try {

                int response_code = conn.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder result = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return(result.toString());

                }else{

                    return("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "exception";
            } finally {
                conn.disconnect();
            }


        }

        @Override
        protected void onPostExecute(String result) {

            try {
                json = new JSONArray(result);
                String s = "";
                if (json.length() != 0) {
                    for (int i = 0; i < json.length(); i++) {
                        s = json.get(i).toString();
                        JSONObject last = new JSONObject(s);
                        last = json.getJSONObject(i);
                        String estado = last.getString("status");
                        datos.add(estado);
                    }

                }

                pDialog.dismiss();
                if (datos.size() > 0) {
                    Toast.makeText(getApplicationContext(), "Guardado Correctamente", Toast.LENGTH_LONG).show();
                    Intent i = new Intent("com.jahesa.apppedidos.listaguia");
                    startActivity(i);
                    Guia_detalle.this.finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Errro al Guardar", Toast.LENGTH_LONG).show();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(600);
                }

            }  catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class Subir_foto extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        URL url_new = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(Guia_detalle.this);
            pDialog.setMessage("Guardando Imagen....");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... params) {
            datos = new ArrayList<String>();
            try {

                // Enter URL address where your php file resides
                url_new = new URL(url+ "hojaruta/Subir_Foto");

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "exception";
            }
            try {
                //Setup HttpURLConnection class to send and receive data from php and mysql
                conn = (HttpURLConnection)url_new.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(10000);
                conn.setRequestMethod("POST");

                // setDoInput and setDoOutput method depict handling of both send and receive
                conn.setDoInput(true);
                conn.setDoOutput(true);

                // Append parameters to URL
                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("vp_guia", params[0])
                        .appendQueryParameter("vp_foto", params[1]);
                String query = builder.build().getEncodedQuery();

                // Open connection for sending data
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                conn.connect();

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return "exception";
            }

            try {

                int response_code = conn.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder result = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return(result.toString());

                }else{

                    return("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "exception";
            } finally {
                conn.disconnect();
            }


        }

        @Override
        protected void onPostExecute(String result) {

            try {
                json = new JSONArray(result);
                String s = "";
                if (json.length() != 0) {
                    for (int i = 0; i < json.length(); i++) {
                        s = json.get(i).toString();
                        JSONObject last = new JSONObject(s);
                        last = json.getJSONObject(i);
                        status = last.getString("STATUS");
                        datos.add(status);
                    }

                }

                pDialog.dismiss();
                if (datos.size() > 0) {
                    Toast.makeText(getApplicationContext(), "Guardado Correctamente", Toast.LENGTH_LONG).show();
                    new Validar_Foto().execute(num_guia);
                } else {
                    Toast.makeText(getApplicationContext(), "Error al guardar foto", Toast.LENGTH_LONG).show();
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    v.vibrate(600);
                }

            }  catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class Validar_Foto extends AsyncTask<String, String, String> {
        HttpURLConnection conn;
        URL url_new = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        @Override
        protected String doInBackground(String... params) {
            datos = new ArrayList<String>();
            try {

                // Enter URL address where your php file resides
                url_new = new URL(url+ "hojaruta/Validar_Foto");

            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "exception";
            }
            try {
                //Setup HttpURLConnection class to send and receive data from php and mysql
                conn = (HttpURLConnection)url_new.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(10000);
                conn.setRequestMethod("POST");

                // setDoInput and setDoOutput method depict handling of both send and receive
                conn.setDoInput(true);
                conn.setDoOutput(true);

                // Append parameters to URL
                Uri.Builder builder = new Uri.Builder()
                        .appendQueryParameter("vp_guia", params[0]);
                String query = builder.build().getEncodedQuery();

                // Open connection for sending data
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                conn.connect();

            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                return "exception";
            }

            try {

                int response_code = conn.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    // Read data sent from server
                    InputStream input = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder result = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    // Pass data to onPostExecute method
                    return(result.toString());

                }else{

                    return("unsuccessful");
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "exception";
            } finally {
                conn.disconnect();
            }


        }

        @Override
        protected void onPostExecute(String result) {

            try {
                json = new JSONArray(result);
                String s = "";
                if (json.length() != 0) {
                    for (int i = 0; i < json.length(); i++) {
                        s = json.get(i).toString();
                        JSONObject last = new JSONObject(s);
                        last = json.getJSONObject(i);
                        cantidad_fotos = last.getInt("cantidad");
                    }
                }
            }  catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }


    public static String encodeToBase64(Bitmap image, Bitmap.CompressFormat compressFormat, int quality) {
        ByteArrayOutputStream byteArrayOS = new ByteArrayOutputStream();
        image.compress(compressFormat, quality, byteArrayOS);
        return Base64.encodeToString(byteArrayOS.toByteArray(), Base64.DEFAULT);
    }

    public static Bitmap decodeBase64(String input) {
        byte[] decodedBytes = Base64.decode(input, 0);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

    @SuppressLint("SimpleDateFormat")
    private String getCode() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");
        String date = dateFormat.format(new Date());
        String photoCode = "img_" + date;
        return photoCode;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            Uri imageUri = uri;
            try {

                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
                byte[] b = baos.toByteArray();
                String encodedImage = Base64.encodeToString(b, Base64.DEFAULT);
                //---------SERVICIO EN SEGUNDO PLANO------
                //Intent intent = new Intent(this, ProgressIntentService.class);
                //intent.putExtra("guia",num_guia);
                //intent.putExtra("foto",encodedImage);
                //intent.setAction(Constants.ACTION_RUN_ISERVICE);
                //startService(intent);
                //-------------------------
               new Subir_foto().execute(num_guia,encodedImage);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public void onClick2(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("waze://?ll=" + lat_extraida + ", " + lon_extraida + "&navigate=yes"));
        this.startActivity(i);
    }

}


