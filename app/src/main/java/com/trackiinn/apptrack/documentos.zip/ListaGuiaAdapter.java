package com.jahesa.apppedidos;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

//import android.app.FragmentManager;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by desarrollo on 18/08/2017.
 */
public class ListaGuiaAdapter extends ArrayAdapter<ListaGuiaCampos> {
   Context context;
    int layoutResourceId;
    //ListaGuiaCampos data[] = null;
    ArrayList<ListaGuiaCampos> data=null;

    public ListaGuiaAdapter(Context context, int layoutResourceId, ArrayList<ListaGuiaCampos> data) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        if(data.size()>0) {
            this.data = data;
        }
    }

    public void UpdateData(ArrayList<ListaGuiaCampos> data) {
        if(data.size()>0) {
            this.data = data;
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        WeatherHolder holder = null;

        if(row == null)
        {
            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);
            holder = new WeatherHolder();
            holder.imgIcon = (ImageView)row.findViewById(R.id.imgIcon);
            holder.imgIcon_mensaje = (ImageView)row.findViewById(R.id.imgIcon_mensaje);
            holder.txtTitle = (TextView)row.findViewById(R.id.txtTitle);
            holder.txtDestino = (TextView)row.findViewById(R.id.txtDestino);
            row.setTag(holder);
        }
        else
        {
            holder = (WeatherHolder)row.getTag();
        }

        final ListaGuiaCampos weather = data.get(position);
        holder.txtTitle.setText(weather.guia);
        holder.txtDestino.setText(weather.destino);
        if(weather.destino==""){
            holder.imgIcon.setVisibility(View.INVISIBLE);
        }
        holder.imgIcon.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(weather.destino!=""){
                    Context c=getContext();
                    Toast.makeText(c, weather.destino , Toast.LENGTH_LONG).show();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    String[] datos_envio=weather.destino.split(",");
                    i.setData(Uri.parse("waze://?ll=" + datos_envio[0] + ", " + datos_envio[1] + "&navigate=yes"));
                    c.startActivity(i);
                }
            }
        });
        holder.txtTitle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Context c=getContext();
                Toast.makeText(c, weather.guia , Toast.LENGTH_LONG).show();
                Intent i = new Intent("com.jahesa.apppedidos.guia_detalle");
                i.putExtra("documento",weather.guia);
                c.startActivity(i);

            }
        });

        return row;
    }


    static class WeatherHolder
    {
        ImageView imgIcon;
        ImageView imgIcon_mensaje;
        TextView txtTitle;
        TextView txtDestino;
    }
}
